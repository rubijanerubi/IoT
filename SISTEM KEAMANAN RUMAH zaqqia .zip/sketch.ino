int Pir = 2;
int Buzzer = 3;
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define I2C_ADDR    0x27
#define LCD_COLUMNS 20
#define LCD_LINES   4

LiquidCrystal_I2C lcd(I2C_ADDR, LCD_COLUMNS, LCD_LINES);

void setup() {
  Serial.begin(9600);
  pinMode(Pir, INPUT);
  pinMode(Buzzer, OUTPUT);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(6,0);
  lcd.print("HOME");
  lcd.setCursor(0,1);
  lcd.print("SECURITY SYSTEM");
  delay(3000);
  lcd.clear();
}

void loop() {
  if(digitalRead(Pir)==LOW){
    Serial.println(Pir);
    lcd.setCursor(0,0);
    lcd.print("AMAN TERKENDALI!");
  }
  if(digitalRead(Pir)==HIGH){
    Serial.println(Pir);
    digitalWrite(Buzzer, HIGH);
    lcd.clear();
    delay(1000);
    lcd.setCursor(6,0);
    lcd.print("ADA");
    lcd.setCursor(2,1);
    lcd.print("MALING !!!");
    lcd.clear();
  
  }
}